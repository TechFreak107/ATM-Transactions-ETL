use Transactions;

show tables;

show create table location;

ALTER TABLE location
ADD CONSTRAINT pk_transaction_id PRIMARY KEY (location_id);

show create table atm;

ALTER TABLE atm
ADD CONSTRAINT pk_transaction_id PRIMARY KEY (atm_id);

ALTER TABLE atm
ADD CONSTRAINT fk_atm_id FOREIGN KEY (atm_location_id) REFERENCES location(location_id);

show create table date;

ALTER TABLE date
ADD CONSTRAINT pk_transaction_id PRIMARY KEY (date_id);

show create table card_type;

ALTER TABLE card_type
ADD CONSTRAINT pk_transaction_id PRIMARY KEY (card_type_id);

show create table transactions;

ALTER TABLE transactions
ADD CONSTRAINT pk_transaction_id PRIMARY KEY (trans_id);

ALTER TABLE transactions
ADD CONSTRAINT fk_transactions_atm_id FOREIGN KEY (atm_id) REFERENCES atm(atm_id);

ALTER TABLE transactions
ADD CONSTRAINT fk_transactions_location_id FOREIGN KEY (location_id) REFERENCES location(location_id);

ALTER TABLE transactions
ADD CONSTRAINT fk_transactions_date_id FOREIGN KEY (date_id) REFERENCES `date`(date_id);

ALTER TABLE transactions
ADD CONSTRAINT fk_transactions_cardtype_id FOREIGN KEY (card_type_id) REFERENCES card_type(card_type_id);





