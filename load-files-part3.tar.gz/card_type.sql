CREATE TABLE card_type (
    card_type_id INT,
    card_type VARCHAR(255)
);

INSERT INTO card_type VALUES
(1, 'CIRRUS'),
(2, 'Dankort'),
(3, 'Dankort - on-us'),
(4, 'Hævekort'),
(5, 'Hævekort - on-us'),
(6, 'Maestro'),
(7, 'MasterCard'),
(8, 'Mastercard - on-us'),
(9, 'VISA'),
(10, 'Visa Dankort'),
(11, 'Visa Dankort - on-us'),
(12, 'VisaPlus');